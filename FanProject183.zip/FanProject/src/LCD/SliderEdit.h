/*
 * SliderEdit.h
 *
 *  Created on: 8.2.2016
 *      Author: Topi
 */

#ifndef SLIDEREDIT_H_
#define SLIDEREDIT_H_


#include "PropertyEdit.h"
#include "LiquidCrystal.h"
#include "BarGraph.h"
#include <string>

class SliderEdit: public PropertyEdit {
public:
	SliderEdit(LiquidCrystal& lcd_, BarGraph&, std::string editTitle, int max_value, int min_value);

	virtual ~SliderEdit();
	void increment();
	void decrement();
	void accept();
	void cancel();
	void setFocus(bool focus);
	void display();
	int getValue();
	void setValue(int value);
private:
	void save();
	void displayEditValue();
	LiquidCrystal& lcd;
	BarGraph& bar;
	std::string title;
	int value;
	int edit;
	bool focus;
	int _max;
	int _min;
	bool flag = false;
};
#endif /* SLIDEREDIT_H_ */
