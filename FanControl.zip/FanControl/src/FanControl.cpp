/*
===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#if defined (__USE_LPCOPEN)
#if defined(NO_BOARD_LIB)
#include "chip.h"
#else
#include "board.h"
#endif
#endif

#include <cr_section_macros.h>
#include "LiquidCrystal.h"
#include "lcd_port.h"
#include "SimpleMenu.h"
#include "IntegerEdit.h"
#include "DecimalEdit.h"
#include "SliderEdit.h"
#include "Co2Edit.h"
#include "lcd_port.h"
#include "TempEdit.h"
#include "PressureEdit.h"
#include "Sensors.h"
#include <cstdio>
#include "gpio_15xx.h"
#include <iostream>
#include <iomanip>
#include <locale>
#include <sstream>
#include <string>

static volatile bool adcdone = false;
static volatile bool adcstart = false;
#define TICKRATE_HZ (100)	/* 100 ticks per second */


extern "C" {

void SysTick_Handler(void)
{
	static uint32_t count;


	count++;
	if (count >= 5) {
		count = 0;
		adcstart = true;
		Board_LED_Toggle(1);
	}
}

void ADC0A_IRQHandler(void)
{
	uint32_t pending;

	pending = Chip_ADC_GetFlags(LPC_ADC0);

	if (pending & ADC_FLAGS_SEQA_INT_MASK) {
		adcdone = true;
	}

	Chip_ADC_ClearFlags(LPC_ADC0, pending);
}

}


// TODO: insert other include files here

// TODO: insert other definitions and declarations here
/*
const int buttonPort [] = {0,0,1,0};
const int buttonPin [] = {10,16,3,0};
*/

const int buttonPort [] = {0,1,0,0};
const int buttonPin [] = {0,3,10,9};

int CheckButtons(){

	if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[0],buttonPin[0])){
			while(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[0],buttonPin[0])){
				delayMicroseconds(100000);
				return 1;
			}
			return 1;
		}

		if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[1],buttonPin[1])){
			while(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[1],buttonPin[1])){
				delayMicroseconds(100000);
				return 2;
			}
			return 2;
		}

		if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[2],buttonPin[2])){
			while(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[2],buttonPin[2])){

				}
				return 3;
			}

		if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[3],buttonPin[3])){
			while(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[3],buttonPin[3])){

				}return 4;
			}

		return 0;

}


int main(void) {

#if defined (__USE_LPCOPEN)
    // Read clock settings and update SystemCoreClock variable
    SystemCoreClockUpdate();
#if !defined(NO_BOARD_LIB)
    // Set up and initialize all required blocks and
    // functions related to the board hardware
    Board_Init();
    Chip_RIT_Init(LPC_RITIMER);
    NVIC_EnableIRQ(RITIMER_IRQn);
    // Set the LED to the state of "On"
    //Board_LED_Set(0, true);
#endif
#endif

    Sensors sensor;
    NVIC_EnableIRQ(ADC0_SEQA_IRQn);
    Chip_ADC_EnableSequencer(LPC_ADC0, ADC_SEQA_IDX);
    SysTick_Config(Chip_Clock_GetSysTickClockRate() / TICKRATE_HZ);

    uint32_t a0, a3;

    // TODO: insert code here
    Chip_RIT_Init(LPC_RITIMER);
    LiquidCrystal lcd(8, 9, 10, 11, 12, 13);

    BarGraph bar(lcd, 50, false);

    lcd.begin(16,2);
    lcd.setCursor(0,0);

	#define max_temperature (50)
	#define min_temperature (10)

	#define max_pressure (128)
	#define min_pressure (0)

    for (int button = 0; button < 8; button++ ){
       	pinMode(button, LOW);
       }

    /*
    for (int button = 4; button < 8; button++ ){
    	pinMode(button, LOW);
    }
*/

    SimpleMenu menu;

    TempEdit temperature(lcd, std::string("1. Temperature"));
    PressureEdit pressure(lcd, std::string("2. Set Pressure"), max_pressure, min_pressure);
    Co2Edit co2(lcd, std::string("3. co2"), max_temperature, min_temperature);

    menu.addItem(new MenuItem(temperature));
    menu.addItem(new MenuItem(pressure));
    menu.addItem(new MenuItem(co2));

    temperature.setValue(21);
    pressure.setValue(75);
    co2.setValue(20);

    menu.event(MenuItem::show); // display first menu item

    int button = 0;
    int tempcount= 0;

    while(true){


    	while(!adcstart) __WFI();
    			adcstart = false;

    			Chip_ADC_StartSequencer(LPC_ADC0, ADC_SEQA_IDX);
    			while(!adcdone) __WFI();
    			adcdone = false;

    			a0 = Chip_ADC_GetDataReg(LPC_ADC0, 0);
    			a3 = Chip_ADC_GetDataReg(LPC_ADC0, 3);

    			sensor.set_co2(ADC_DR_RESULT(a3));
    			sensor.set_temp(ADC_DR_RESULT(a0));

    	temperature.setValue(sensor.get_temp());
    	//co2.setValue(sensor.get_co2());

    	int pressureValue = pressure.getValue();

    	button=CheckButtons();
    	switch(button){

    	case 1:
    	    	menu.event(MenuItem::down);
    	    	break;
    	case 2:
    	    	menu.event(MenuItem::up);
    	    	break;
    	case 3:
    	    	menu.event(MenuItem::ok);
    	    	break;
    	case 4:
    			menu.event(MenuItem::back);
    			break;
    	case 0:
    			tempcount++;
    			if (tempcount > 50){
					menu.event(MenuItem::update);
					tempcount = 0;
    			}
    		    break;
    	}
    }

    
    // TODO: insert code here

    // Force the counter to be placed into memory
    volatile static int i = 0 ;
    // Enter an infinite loop, just incrementing a counter
    while(1) {
        i++ ;
    }
    return 0 ;
}





