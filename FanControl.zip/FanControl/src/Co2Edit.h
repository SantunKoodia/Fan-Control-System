/*
 * Co2Edit.h
 *
 *  Created on: 9.3.2016
 *      Author: Topi
 */

#ifndef CO2EDIT_H_
#define CO2EDIT_H_

#include "PropertyEdit.h"
#include "LiquidCrystal.h"
#include <string>

class Co2Edit: public PropertyEdit {
public:
	Co2Edit(LiquidCrystal& lcd_, std::string editTitle, int max_value, int min_value);
	virtual ~Co2Edit();
	void increment();
	void decrement();
	void accept();
	void cancel();
	void setFocus(bool focus);
	void display();
	void update();
	int getValue();
	void setValue(int value);

private:
	void save();
	void displayEditValue();
	LiquidCrystal& lcd;
	std::string title;
	int value;
	int edit;
	bool focus;
	int _max;
	int _min;

};

#endif /* CO2EDIT_H_ */
