/*
 * SliderEdit.cpp
 *
 *  Created on: 8.2.2016
 *      Author: Topi
 */

#include "SliderEdit.h"
#include "BarGraph.h"
#include <cstdio>


SliderEdit::SliderEdit(LiquidCrystal& lcd_, BarGraph &bar_, std::string editTitle, int max_value, int min_value) : lcd(lcd_),bar(bar_), title(editTitle) {

	value = 0;
	edit = 0;
	focus = false;
	_max = max_value;
	_min = min_value;
}

SliderEdit::~SliderEdit() {
}

void SliderEdit::increment() {
	if (edit < _max){
	edit++;
	}
}

void SliderEdit::decrement() {
	if (edit > _min){
	edit--;
	}
}

void SliderEdit::accept() {
	save();
}

void SliderEdit::cancel() {
	edit = value;
}


void SliderEdit::setFocus(bool focus) {
	this->focus = focus;
}

void SliderEdit::display() {

	lcd.clear();
	lcd.setCursor(0,0);
	lcd.Print(title);
	lcd.setCursor(10,0);
	char s[16];

	if(focus) {
		snprintf(s, 16, "[%4d]", edit);
	}
	else {
		snprintf(s, 16, "%4d", edit);
	}

	lcd.Print(s);

	lcd.setCursor(0,1);
	lcd.Print("-");

	bar.draw((edit-_min)/((_max-_min)/50));

	lcd.setCursor(11,1);
	lcd.Print("+");

}


void SliderEdit::save() {
	// set current value to be same as edit value
	value = edit;
	// todo: save current value for example to EEPROM for permanent storage
}


int SliderEdit::getValue() {
	return value;
}
void SliderEdit::setValue(int value) {
	edit = value;
	save();
}

