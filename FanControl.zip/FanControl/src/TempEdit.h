/*
 * TempEdit.h
 *
 *  Created on: 9.3.2016
 *      Author: Topi
 */

#ifndef TEMPEDIT_H_
#define TEMPEDIT_H_

#include "PropertyEdit.h"
#include "LiquidCrystal.h"
#include <string>

class TempEdit: public PropertyEdit {
public:
	TempEdit(LiquidCrystal& lcd_, std::string editTitle);
	virtual ~TempEdit();
	void increment();
	void decrement();
	void accept();
	void cancel();
	void setFocus(bool focus);
	void display();
	int getValue();
	void setValue(int value);
	void update();
private:
	void save();
	void displayEditValue();
	LiquidCrystal& lcd;
	std::string title;
	int value;
	int edit;
	bool focus;
	int _max;
	int _min;

};

#endif /* TEMPEDIT_H_ */
