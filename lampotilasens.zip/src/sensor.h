/*
 * sensor.h
 *
 *  Created on: 2 Mar 2016
 *      Author: Svetlana
 */
#include "chip.h"
#include "board.h"
#ifndef SENSOR_H_
#define SENSOR_H_

class sensor {
public:
	sensor();
	void set_temp(int a);
	int get_temp();
	virtual ~sensor();
private:
	int temperature;
};

#endif /* SENSOR_H_ */
