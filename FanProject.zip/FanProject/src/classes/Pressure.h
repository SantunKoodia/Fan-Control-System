/*
 * Pressure.h
 *
 *  Created on: 9.3.2016
 *      Author: Santtu
 */

#ifndef PSINCLUDES_PRESSURE_H_
#define PSINCLUDES_PRESSURE_H_


#include <cstring>
#include <cstdio>

#include "../libraries/ModBusMaster.h"
#include "../libraries/SerialPort.h"
#include "../libraries/word.h" //tarviikk??
#include "../libraries/crc16.h" //tarviiko??
#include "../libraries/I2C.h"
#include "Syssi.h"

class Pressure {
public:
	Pressure();
	virtual ~Pressure();
	int GetPressure();
};

#endif /* PSINCLUDES_PRESSURE_H_ */
