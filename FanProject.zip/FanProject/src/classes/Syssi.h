/*
 * Syssi.h
 *
 *  Created on: Mar 9, 2016
 *      Author: Ville
 */

#ifndef SYSSI_H_
#define SYSSI_H_

void Sleep(int ms);


#endif /* SYSSI_H_ */
