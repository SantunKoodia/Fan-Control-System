/*
 * Co2Edit.cpp
 *
 *  Created on: 9.3.2016
 *      Author: Topi
 */

#include "Co2Edit.h"
#include <cstdio>

Co2Edit::Co2Edit(LiquidCrystal& lcd_, std::string editTitle, int max_value, int min_value) : lcd(lcd_), title(editTitle) {
	value = 0;
	edit = 0;
	focus = false;
	_max = max_value;
	_min = min_value;
}

Co2Edit::~Co2Edit() {
}

void Co2Edit::increment() {
	if (edit < _max){
	edit++;
	}
}

void Co2Edit::decrement() {
	if (edit > _min){
	edit--;
	}
}

void Co2Edit::accept() {
	save();
}

void Co2Edit::cancel() {
	edit = value;
}

void Co2Edit::update(){

}

void Co2Edit::setFocus(bool focus) {
	this->focus = focus;
}

void Co2Edit::display() {

	lcd.clear();
	lcd.setCursor(0,0);
	lcd.Print(title);
	lcd.setCursor(0,1);
	char s[16];


	if(focus) {
		snprintf(s, 16, "     [%4d]     ", edit);
	}
	else {
		snprintf(s, 16, "      %4d      ", edit);
	}
	lcd.Print(s);
}


void Co2Edit::save() {
	// set current value to be same as edit value
	value = edit;
	// todo: save current value for example to EEPROM for permanent storage
}


int Co2Edit::getValue() {
	return value;
}
void Co2Edit::setValue(int value) {
	edit = value;
	save();
}


