/*
 * FreqContrl.h
 *
 *  Created on: 10.3.2016
 *      Author: Santtu
 */

#ifndef CONTROLLER_FREQCONTRL_H_
#define CONTROLLER_FREQCONTRL_H_
void Setup();
void SetFanSpeed(int inputSpeed);

#endif /* CONTROLLER_FREQCONTRL_H_ */
