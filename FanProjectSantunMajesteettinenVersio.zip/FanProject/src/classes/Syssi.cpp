/*
 * Syssi.cpp
 *
 *  Created on: Mar 9, 2016
 *      Author: Ville
 */

#include "Syssi.h"
#include "board.h"
#include "chip.h"

const int buttonPort [] = {0,0,1,0};
const int buttonPin [] = {10,16,3,0};

int recentButton=0;
static volatile int counter;
static volatile uint32_t systicks;


void SysCheckButtons(){

	if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[0],buttonPin[0])){
		recentButton=1;
	}

	if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[1],buttonPin[1])){
		recentButton=2;
	}

	if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[2],buttonPin[2])){
		recentButton=3;
	}

	if(!Chip_GPIO_GetPinState(LPC_GPIO,buttonPort[3],buttonPin[3])){
		recentButton=4;
	}
}



#ifdef __cplusplus
extern "C" {
#endif
/**
 * @brief	Handle interrupt from SysTick timer
 * @return	Nothing
 */
void SysTick_Handler(void)
{

	SysCheckButtons();

	static uint32_t count;

	systicks++;
	if(counter > 0) counter--;

	count++;
	if (count >= 5) {
		count = 0;
		adcstart = true;
	}
}
#ifdef __cplusplus
}
#endif

void Sleep(int ms)
{
	counter = ms;
	while(counter > 0) {
		__WFI();
	}
}



/* this function is required by the modbus library */
uint32_t millis() {
	return systicks;
}


int ReturnButtons(){
	int returning = recentButton;
	recentButton=0;
	return returning;
}
