/*
 * Syssi.h
 *
 *  Created on: Mar 9, 2016
 *      Author: Ville
 */

#ifndef SYSSI_H_
#define SYSSI_H_

extern bool adcstart;
void Sleep(int ms);
int ReturnButtons();


#endif /* SYSSI_H_ */
