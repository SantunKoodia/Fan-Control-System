/*
 * Syssi.cpp
 *
 *  Created on: Mar 9, 2016
 *      Author: Ville
 */

#include "Syssi.h"
#include "board.h"
#include "chip.h"


static volatile int counter;
static volatile uint32_t systicks;
#ifdef __cplusplus
extern "C" {
#endif
/**
 * @brief	Handle interrupt from SysTick timer
 * @return	Nothing
 */
void SysTick_Handler(void)
{

	static uint32_t count;

	systicks++;
	if(counter > 0) counter--;

	count++;
	if (count >= 5) {
		count = 0;
		adcstart = true;
	}
}
#ifdef __cplusplus
}
#endif

void Sleep(int ms)
{
	counter = ms;
	while(counter > 0) {
		__WFI();
	}
}



/* this function is required by the modbus library */
uint32_t millis() {
	return systicks;
}
