/*
 * PressureEdit.h
 *
 *  Created on: 9.3.2016
 *      Author: Topi
 */

#ifndef PRESSUREEDIT_H_
#define PRESSUREEDIT_H_

#include "PropertyEdit.h"
#include "LiquidCrystal.h"
#include <string>

class PressureEdit: public PropertyEdit {
public:
	PressureEdit(LiquidCrystal& lcd_, std::string editTitle, int max_value, int min_value);
	virtual ~PressureEdit();
	void increment();
	void decrement();
	void accept();
	void update();
	void cancel();
	void setFocus(bool focus);
	void display();
	int getValue();
	void setValue(int value);
	void getDesiredValue();
private:
	void save();
	void displayEditValue();
	LiquidCrystal& lcd;
	std::string title;
	int value;
	int edit;
	bool focus;
	int _max;
	int _min;

};

#endif /* PRESSUREEDIT_H_ */
