/*
 * TempEdit.cpp
 *
 *  Created on: 9.3.2016
 *      Author: Topi
 */

#include "TempEdit.h"
#include <cstdio>

TempEdit::TempEdit(LiquidCrystal& lcd_, std::string editTitle) : lcd(lcd_), title(editTitle) {
	value = 0;
	edit = 0;
	focus = false;

}

TempEdit::~TempEdit() {
}

void TempEdit::increment() {
	if (edit < _max){
	edit++;
	}
}

void TempEdit::decrement() {
	if (edit > _min){
	edit--;
	}
}

void TempEdit::accept() {
	save();
}

void TempEdit::cancel() {
	edit = value;
}


void TempEdit::setFocus(bool focus) {
	this->focus = focus;
}

void TempEdit::display() {

	lcd.clear();
	lcd.setCursor(0,0);
	lcd.Print(title);
	lcd.setCursor(0,1);
	char s[16];

	snprintf(s, 16, "      %4d      ", edit);

	lcd.Print(s);

}


void TempEdit::save() {
	// set current value to be same as edit value
	value = edit;
	// todo: save current value for example to EEPROM for permanent storage
}

void TempEdit::update(){
	display();
}
int TempEdit::getValue() {
	return value;
}
void TempEdit::setValue(int value) {
	edit = value;
	save();
}

