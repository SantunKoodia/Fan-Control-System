

#include "DecimalEdit.h"
#include <cstdio>
#include <math.h>
#include <string>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <locale>
#include <sstream>

DecimalEdit::DecimalEdit(LiquidCrystal& lcd_, std::string editTitle, float max_value, float min_value) : lcd(lcd_), title(editTitle) {
	value = 0;
	edit = 0;
	focus = false;
	_max = max_value;
	_min = min_value;
}

DecimalEdit::~DecimalEdit() {
}

void DecimalEdit::increment() {
	if (edit < _max){
	edit=edit+0.1;
	}
}

void DecimalEdit::decrement() {
	if (edit >
	_min){
	edit=edit-0.1;
	}
}

void DecimalEdit::accept() {
	save();
}

void DecimalEdit::cancel() {
	edit = value;
}


void DecimalEdit::setFocus(bool focus) {
	this->focus = focus;
}


void DecimalEdit::display() {
	lcd.clear();
	lcd.setCursor(0,0);
	lcd.Print(title);
	lcd.setCursor(0,1);


		char s[16];
		float adc_read = edit;

		int d1 = adc_read;            // Get the integer part
		float f2 = adc_read - d1;     // Get fractional part
		int d2 = trunc(f2 * 10);   // Turn into integer


	if(focus) {

		snprintf(s, 16, "     [%d.%d]     ", d1,d2);
	}
	else {
		snprintf(s, 16, "      %d.%d      ", d1,d2);
	}

	lcd.Print(s);
}


void DecimalEdit::save() {
	// set current value to be same as edit value
	value = edit;
	// todo: save current value for example to EEPROM for permanent storage
}


float DecimalEdit::getValue() {
	return value;
}

void DecimalEdit::setValue(float value) {
	edit = value;
	save();
}
