/*
 * PressureEdit.cpp
 *
 *  Created on: 9.3.2016
 *      Author: Topi
 */

#include "PressureEdit.h"

#include <cstdio>

PressureEdit::PressureEdit(LiquidCrystal& lcd_, std::string editTitle, int max_value, int min_value) : lcd(lcd_), title(editTitle) {
	value = 0;
	edit = 0;
	focus = false;
	_max = max_value;
	_min = min_value;
}

PressureEdit::~PressureEdit() {
}

void PressureEdit::increment() {
	if (edit < _max){
	edit++;
	}
}

void PressureEdit::decrement() {
	if (edit > _min){
	edit--;
	}
}

void PressureEdit::accept() {
	save();
}

void PressureEdit::cancel() {
	edit = value;
}


void PressureEdit::setFocus(bool focus) {
	this->focus = focus;
}

void PressureEdit::display() {

	lcd.clear();
	lcd.setCursor(0,0);
	lcd.Print(title);
	lcd.setCursor(0,1);
	char s[16];


	if(focus) {
		snprintf(s, 16, "     [%4d]     ", edit);
	}
	else {
		snprintf(s, 16, "      %4d      ", edit);
	}
	lcd.Print(s);
}


void PressureEdit::save() {
	// set current value to be same as edit value
	value = edit;
	// todo: save current value for example to EEPROM for permanent storage
}

void PressureEdit::update(){

}

int PressureEdit::getValue() {
	return value;
}
void PressureEdit::setValue(int value) {
	edit = value;
	save();
}

/*
int getDisaredValue(){
	return edit;
}
*/
